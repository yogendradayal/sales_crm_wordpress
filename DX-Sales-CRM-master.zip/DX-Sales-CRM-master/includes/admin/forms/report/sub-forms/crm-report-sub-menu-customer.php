<?php

/**
 *
 * Vertical sub-menu for Customer
 *
 * List all pre-defined Customer Report
 *
*/

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ){ exit; }

echo apply_filters( 'dx_crm_report_sub_menu', array() );
?>