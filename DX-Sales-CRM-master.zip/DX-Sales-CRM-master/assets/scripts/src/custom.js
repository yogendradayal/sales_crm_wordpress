jQuery(document).ready(function($){
	
	$('.datepicker').datepicker({ dateFormat: 'yy-mm-dd' });
	
	jQuery('.actions').removeClass('alignleft');
});